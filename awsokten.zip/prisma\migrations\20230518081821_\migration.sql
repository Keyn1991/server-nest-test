-- AlterTable
ALTER TABLE "Car" ADD COLUMN     "images" TEXT[];
